#!/bin/bash

LOG_FILE="report_$(basename "$0" .sh).log"

PID=$$
CURRENT_DATE=$(date '+%Y-%m-%d')
CURRENT_TIME=$(date '+%H:%M:%S')

echo "[$PID] $CURRENT_DATE $CURRENT_TIME Скрипт запущен" >> "$LOG_FILE"

RANDOM_SECONDS=$((RANDOM % 1771 + 30))

sleep "$RANDOM_SECONDS"

MINUTES=$((RANDOM_SECONDS / 60))

echo "[$PID] $CURRENT_DATE $CURRENT_TIME Скрипт завершился, работал $MINUTES минут" >> "$LOG_FILE"


